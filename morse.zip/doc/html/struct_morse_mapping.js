var struct_morse_mapping =
[
    [ "character", "struct_morse_mapping.html#a90162406305fac21fdfb450ab482b0da", null ],
    [ "morse", "struct_morse_mapping.html#a50e51288ab02eff98554dfd37e471e4b", null ]
];