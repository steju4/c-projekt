var searchData=
[
  ['encode_5fchar_0',['encode_char',['../main_8c.html#a52cb08aca68f680f4d8585f71e985f68',1,'encode_char(char c):&#160;main.c'],['../morse_8h.html#a52cb08aca68f680f4d8585f71e985f68',1,'encode_char(char c):&#160;main.c']]],
  ['encode_5ftext_1',['encode_text',['../main_8c.html#a5641c8e6ccab0d15bfad0653bd07a301',1,'encode_text(const char *text, bool slash_mode):&#160;main.c'],['../morse_8h.html#a5641c8e6ccab0d15bfad0653bd07a301',1,'encode_text(const char *text, bool slash_mode):&#160;main.c']]]
];
