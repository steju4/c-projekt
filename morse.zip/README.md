# Morse Code Utility

Ein Kommandozeilenprogramm zur Codierung und Dekodierung von Morsezeichen.

Projektarbeit in "Programmieren - C/C++" beim Dozenten Thomas Staudacher.

## Autor
Julian Stengele  
Kurs TIK24  
julian.stengele@gmail.com

## Build-Anleitung

```bash
mkdir build
cd build
cmake ..
cmake --build .
